# -*- coding: utf-8 -*-
"""
Created on Tue May  2 19:49:54 2023

@author: HP
"""

from robot_model import RobotModel
from robot_view import RobotView
from robot_controller import RobotController

if __name__ == "__main__":
    model = RobotModel()
    view = RobotView()
    controller = RobotController(model, view)
    controller.run() 

    