# -*- coding: utf-8 -*-
"""
Created on Tue May  2 19:49:03 2023

@author: HP
"""
class RobotController:
    def __init__(self, model, view):
        self.model = model
        self.view = view

    def run(self):
        while True:
            elevation, rotation, length = self.view.get_user_input()
            self.model.move_elevation(elevation)
            self.model.move_rotation(rotation)
            self.model.move_length(length)
            self.view.show_robot_position(self.model.elevation, self.model.rotation, self.model.length)
