# -*- coding: utf-8 -*-
"""
Created on Tue May  2 19:47:53 2023

@author: HP
"""


class RobotView:
    def get_user_input(self):
        elevation = int(input("Ingrese el valor de elevación: "))
        rotation = int(input("Ingrese el valor de giro: "))
        length = int(input("Ingrese el valor de longitud: "))
        return elevation, rotation, length

    def show_robot_position(self, elevation, rotation, length):
        print(f"El robot está en la posición: elevación={elevation}, giro={rotation}, longitud={length}")
    
    