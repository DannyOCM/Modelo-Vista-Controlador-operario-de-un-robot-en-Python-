# -*- coding: utf-8 -*-
"""
Created on Tue May  2 19:44:58 2023

@author: HP
"""

class RobotModel:
    def __init__(self):
        self.elevation = 0
        self.rotation = 0
        self.length = 0

    def move_elevation(self, value):
        self.elevation += value

    def move_rotation(self, value):
        self.rotation += value

    def move_length(self, value):
        self.length += value

    def stop_movement(self):
        self.elevation = 0
        self.rotation = 0
        self.length = 0
        